(function(){
  const STORAGE_KEY = 'oxinv_theme_v1';

  function clamp(n, min, max){ return Math.min(max, Math.max(min, n)); }

  function hexToRgb(hex){
    const s = (hex||'#000').replace('#','');
    if(s.length === 3){
      return { r: parseInt(s[0]+s[0],16), g: parseInt(s[1]+s[1],16), b: parseInt(s[2]+s[2],16) };
    }
    if(s.length === 6){
      return { r: parseInt(s.slice(0,2),16), g: parseInt(s.slice(2,4),16), b: parseInt(s.slice(4,6),16) };
    }
    return { r: 12, g: 12, b: 12 };
  }
  function rgbToHex({r,g,b}){ const h=n=>('0'+clamp(n,0,255).toString(16)).slice(-2); return `#${h(r)}${h(g)}${h(b)}`; }
  function rgba({r,g,b}, a){ return `rgba(${r}, ${g}, ${b}, ${clamp(a,0,1)})`; }

  function applyTheme(theme){
    const root = document.documentElement;
    const inv = hexToRgb(theme.invHex || '#0c0c0c');
    const brd = hexToRgb(theme.borderHex || '#000000');
    const lab = hexToRgb(theme.labelHex || '#22232c');
    root.style.setProperty('--oxinv-inv-bg', rgba(inv, Number(theme.invAlpha ?? 0.4)));
    root.style.setProperty('--oxinv-inv-border', rgba(brd, Number(theme.borderAlpha ?? 0.2)));
    root.style.setProperty('--oxinv-label-bg', rgbToHex(lab));
  }

  function loadTheme(){ try{ const raw = localStorage.getItem(STORAGE_KEY); if(raw) return JSON.parse(raw);}catch{} return { invHex:'#0c0c0c', invAlpha:0.4, borderHex:'#000000', borderAlpha:0.2, labelHex:'#22232c' }; }
  function saveTheme(t){ localStorage.setItem(STORAGE_KEY, JSON.stringify(t)); }

  function buildUI(){
    // Modal
    const modal = document.createElement('div');
    modal.id = 'oxinv-settings-modal';
    modal.innerHTML = `
      <div id="oxinv-settings-dialog">
        <h3>Inventory Settings</h3>
        <div class="oxinv-field">
          <label>Tile color</label>
          <div>
            <input id="oxinv-inv-hex" type="color" />
            <input id="oxinv-inv-alpha" type="range" min="0" max="1" step="0.05" />
          </div>
        </div>
        <div class="oxinv-field">
          <label>Tile border</label>
          <div>
            <input id="oxinv-border-hex" type="color" />
            <input id="oxinv-border-alpha" type="range" min="0" max="1" step="0.05" />
          </div>
        </div>
        <div class="oxinv-field">
          <label>Label bar</label>
          <div>
            <input id="oxinv-label-hex" type="color" />
          </div>
        </div>
        <div id="oxinv-actions">
          <button id="oxinv-close">Close</button>
          <button id="oxinv-save">Save</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const theme = loadTheme();
    const invHex = modal.querySelector('#oxinv-inv-hex');
    const invAlpha = modal.querySelector('#oxinv-inv-alpha');
    const borderHex = modal.querySelector('#oxinv-border-hex');
    const borderAlpha = modal.querySelector('#oxinv-border-alpha');
    const labelHex = modal.querySelector('#oxinv-label-hex');

    invHex.value = theme.invHex; invAlpha.value = theme.invAlpha;
    borderHex.value = theme.borderHex; borderAlpha.value = theme.borderAlpha;
    labelHex.value = theme.labelHex;

    const applyFromInputs = ()=>applyTheme({
      invHex: invHex.value,
      invAlpha: Number(invAlpha.value),
      borderHex: borderHex.value,
      borderAlpha: Number(borderAlpha.value),
      labelHex: labelHex.value,
    });

    invHex.addEventListener('input', applyFromInputs);
    invAlpha.addEventListener('input', applyFromInputs);
    borderHex.addEventListener('input', applyFromInputs);
    borderAlpha.addEventListener('input', applyFromInputs);
    labelHex.addEventListener('input', applyFromInputs);

    modal.querySelector('#oxinv-close').addEventListener('click', ()=>{ modal.style.display = 'none'; });
    modal.querySelector('#oxinv-save').addEventListener('click', ()=>{
      const newTheme = {
        invHex: invHex.value,
        invAlpha: Number(invAlpha.value),
        borderHex: borderHex.value,
        borderAlpha: Number(borderAlpha.value),
        labelHex: labelHex.value,
      };
      saveTheme(newTheme);
      modal.style.display = 'none';
    });

    // Fallback key
    window.addEventListener('keydown', (e)=>{ if(e.key === 'F7'){ modal.style.display = (modal.style.display === 'flex') ? 'none' : 'flex'; }});

    // Inline button under CLOSE
    function ensureInlineButton(){
      if(document.getElementById('oxinv-settings-inline')) return;
      const container = document.querySelector('.inventory-control .inventory-control-wrapper') || document.querySelector('.inventory-control-wrapper');
      if(!container) return;
      const buttons = Array.from(container.querySelectorAll('.inventory-control-button'));
      if(!buttons.length) return;
      const closeBtn = buttons.slice().reverse().find(b => /close/i.test(b.textContent||b.innerText||'')) || buttons[buttons.length-1];
      const inline = document.createElement('button');
      inline.id = 'oxinv-settings-inline';
      inline.className = 'inventory-control-button';
      inline.textContent = 'SETTINGS';
      inline.addEventListener('click', ()=>{ modal.style.display = 'flex'; });
      closeBtn.insertAdjacentElement('afterend', inline);
    }

    const obs = new MutationObserver(()=>{ ensureInlineButton(); });
    obs.observe(document.documentElement || document.body, { childList: true, subtree: true });
    ensureInlineButton();

    // Apply saved theme initially
    applyTheme(theme);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildUI); else buildUI();
})();
