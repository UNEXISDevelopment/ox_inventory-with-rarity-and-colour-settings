(function(){
  const RARITY_CLASS_PREFIX = 'rarity-';
  const HOTBAR_SLOT_SELECTOR = '.hotbar-item-slot';
  const INVENTORY_SLOT_SELECTOR = '.inventory-slot';
  const SLOT_NUMBER_SELECTOR = '.inventory-slot-number';
  const LABEL_SELECTOR = '.inventory-slot-label-text';

  const rarityByName = Object.create(null);
  const rarityByImage = Object.create(null); // image basename -> rarity
  const rarityByLabel = Object.create(null); // normalized label -> rarity

  async function loadRarityMapFromLua(){
    try {
      const base = 'nui://ox_inventory/data/';
      const [itemsLua, weaponsLua] = await Promise.all([
        fetch(base + 'items.lua').then(r => r.ok ? r.text() : ''),
        fetch(base + 'weapons.lua').then(r => r.ok ? r.text() : '')
      ]);
      if(itemsLua) parseItemsLua(itemsLua);
      if(weaponsLua) parseWeaponsLua(weaponsLua);
    } catch(err) { /* ignore */ }
  }

  function parseItemsLua(src){
    let current = null, depth = 0;
    const lines = src.split(/\r?\n/);
    for(const raw of lines){
      const line = raw.trim();
      let m = line.match(/^\[\s*['"]([^'\"]+)['"]\s*\]\s*=\s*\{\s*$/);
      if(m){ current = m[1]; depth = 1; continue; }
      if(current){
        if(line.includes('{')) depth += (line.match(/\{/g)||[]).length;
        if(line.includes('}')) depth -= (line.match(/\}/g)||[]).length;
        m = line.match(/\brarity\s*=\s*['"]([A-Za-z_-]+)['"]/);
        if(m){ rarityByName[current] = m[1].toLowerCase(); }
        m = line.match(/\bimage\s*=\s*['"]([^'\"]+)['"]/);
        if(m){
          const img = m[1].replace(/\.[a-zA-Z0-9]+$/, '').toLowerCase();
          if(rarityByName[current]) rarityByImage[img] = rarityByName[current];
        }
        if(depth <= 0) current = null;
      }
    }
  }

  function parseWeaponsLua(src){
    // Walk Weapons and Ammo tables capturing label/rarity and mapping aliases
    const lines = src.split(/\r?\n/);
    let depth = 0; let scope = null; // 'Weapons' | 'Ammo'
    let curKey = null, curDepth = 0, curLabel = null, curRarity = null;

    const commit = () => {
      if(!curKey || !curRarity) return;
      const rarity = String(curRarity).toLowerCase();
      const key = String(curKey);
      const lower = key.toLowerCase();
      rarityByName[key] = rarity;
      rarityByName[lower] = rarity;
      if(scope === 'Weapons' && lower.startsWith('weapon_')){
        const suffix = lower.slice('weapon_'.length);
        rarityByName[suffix] = rarity;
        rarityByName['weapon_' + suffix] = rarity;
        rarityByImage[suffix] = rarity;
        rarityByImage['weapon_' + suffix] = rarity;
      }
      if(curLabel){
        const norm = String(curLabel).toLowerCase().replace(/[^a-z0-9]/g,'');
        if(norm) rarityByLabel[norm] = rarity;
      }
    };

    for(const raw of lines){
      const line = raw.trim();
      if(line.includes('{')) depth += (line.match(/\{/g)||[]).length;
      if(line.includes('}')) depth -= (line.match(/\}/g)||[]).length;

      if(scope == null){
        if(/\bWeapons\s*=\s*\{/.test(line)) { scope = 'Weapons'; curKey=null; curDepth=0; curLabel=null; curRarity=null; continue; }
        if(/\bAmmo\s*=\s*\{/.test(line)) { scope = 'Ammo'; curKey=null; curDepth=0; curLabel=null; curRarity=null; continue; }
        continue;
      }

      if(scope && depth <= 1 && /\}/.test(line)){
        commit(); scope=null; curKey=null; curDepth=0; curLabel=null; curRarity=null; continue;
      }

      let m = line.match(/^\[\s*['"]([^'"\]]+)['"]\s*\]\s*=\s*\{\s*$/);
      if(m){ commit(); curKey=m[1]; curDepth=1; curLabel=null; curRarity=null; continue; }

      if(curKey){
        if(line.includes('{')) curDepth += (line.match(/\{/g)||[]).length;
        if(line.includes('}')) curDepth -= (line.match(/\}/g)||[]).length;
        let lm = line.match(/\blabel\s*=\s*['"]([^'\"]+)['"]/); if(lm) curLabel = lm[1];
        let rm = line.match(/\brarity\s*=\s*['"]([^'\"]+)['"]/); if(rm) curRarity = rm[1];
        if(curDepth <= 0){ commit(); curKey=null; curDepth=0; curLabel=null; curRarity=null; }
      }
    }

    // Fallback regex pass
    if(Object.keys(rarityByName).length === 0){
      const re = /\[\s*['"]([^'\"]+)['"]\s*\]\s*=\s*\{[\s\S]*?\brarity\s*=\s*['"]([^'\"]+)['"]/g;
      let m; while((m = re.exec(src))){
        const key = (m[1]||'').trim(); const rarity = (m[2]||'').trim().toLowerCase(); if(!key) continue;
        const lower = key.toLowerCase(); rarityByName[key]=rarity; rarityByName[lower]=rarity;
        if(lower.startsWith('weapon_')){ const s = lower.slice('weapon_'.length); rarityByName[s]=rarity; rarityByName['weapon_'+s]=rarity; rarityByImage[s]=rarity; rarityByImage['weapon_'+s]=rarity; }
      }
    }
  }

  function removeRarityClasses(el){ if(!el) return; const rm=[]; el.classList.forEach(c=>{ if(c.startsWith(RARITY_CLASS_PREFIX)) rm.push(c); }); rm.forEach(c=>el.classList.remove(c)); }

  function findInventorySlotByNumber(n){ const inv=document.querySelectorAll(INVENTORY_SLOT_SELECTOR); for(const slot of inv){ const num=slot.querySelector(SLOT_NUMBER_SELECTOR); if(num){ const v=parseInt(num.textContent,10); if(Number.isInteger(v) && v===n) return slot; } } return null; }

  function extractNameFromSlot(slotEl){
    const label = slotEl.querySelector(LABEL_SELECTOR)?.textContent?.trim();
    const bg = slotEl.style && slotEl.style.backgroundImage || '';
    let file = null; const m = /url\(["']?([^\)"']+)["']?\)/.exec(bg);
    if(m){ try{ const url=new URL(m[1], window.location.href); file = url.pathname.split('/').pop()||null; } catch{ file = m[1].split('/').pop()||null; } if(file) file=file.replace(/\.[a-zA-Z0-9]+$/, '').toLowerCase(); }
    return { label, file };
  }

  function computeRarityForSlot(slotEl){
    const { file, label } = extractNameFromSlot(slotEl);
    if(file && rarityByImage[file]) return rarityByImage[file];
    if(file && rarityByName[file]) return rarityByName[file];
    if(label){ const norm = label.toLowerCase().replace(/[^a-z0-9]/g,''); if(rarityByLabel[norm]) return rarityByLabel[norm]; }
    return null;
  }

  function applyRarityToSlot(slotEl){ const r = computeRarityForSlot(slotEl); removeRarityClasses(slotEl); if(r) slotEl.classList.add(RARITY_CLASS_PREFIX + r); }
  function updateInventory(){ document.querySelectorAll(INVENTORY_SLOT_SELECTOR).forEach(applyRarityToSlot); }
  function updateOneHotbarSlot(slotEl){ applyRarityToSlot(slotEl); const numEl = slotEl.querySelector(SLOT_NUMBER_SELECTOR); const n = numEl ? parseInt(numEl.textContent,10) : NaN; if(!Number.isInteger(n)) return; const invSlot = findInventorySlotByNumber(n); if(!invSlot) return; const classes = Array.from(invSlot.classList).filter(c=>c.startsWith(RARITY_CLASS_PREFIX)); removeRarityClasses(slotEl); if(classes.length) slotEl.classList.add(classes[0]); }
  function updateHotbar(){ document.querySelectorAll(HOTBAR_SLOT_SELECTOR).forEach(updateOneHotbarSlot); }
  function updateAll(){ updateInventory(); updateHotbar(); }

  let rafId=null; function scheduleUpdate(){ if(rafId!=null) return; rafId=requestAnimationFrame(()=>{ rafId=null; updateAll(); }); }
  const obs=new MutationObserver(scheduleUpdate); obs.observe(document.documentElement||document.body,{subtree:true,childList:true,attributes:true});

  loadRarityMapFromLua().finally(()=>{ if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', updateAll); } else { updateAll(); } });
})();
