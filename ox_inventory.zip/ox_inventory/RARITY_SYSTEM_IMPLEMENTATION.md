## Rarity system and color settings

This document explains what was added to ox_inventory to support item/weapon/ammo rarities and a persistent UI theme color picker, where the SETTINGS button sits under CLOSE in the inventory controls.

### What you get

- Rarity-powered background colors for tiles in:
  - Inventory grid items
  - Hotbar slots
  - Item notifications
- Supported sources for rarity:
  - `data/items.lua` item entries
  - `data/weapons.lua` Weapons entries
  - `data/weapons.lua` Ammo entries
- A small SETTINGS panel to change base inventory colors (tile, border, label bar) with persistence via localStorage. Rarity colors still take priority when present.

---

## Files added/changed

- `web/build/index.html`
  - Loads the helper and settings assets after the main bundle and CSS:
    - `./assets/rarity-hotbar.js`
    - `./assets/settings.css`
    - `./assets/settings.js`

- `web/build/assets/index-9aba2ab3.css` (existing)
  - Added CSS classes for rarity backgrounds and optional glow:
    - `.inventory-slot.rarity-common` (white, subtle)
    - `.inventory-slot.rarity-legendary` (purple)
    - `.inventory-slot.rarity-epic` (gold)
  - Same classes are applied to `.hotbar-item-slot` and `.item-notification-item-box`.

- `web/build/assets/rarity-hotbar.js` (new)
  - A post-bundle runtime enhancer that:
    - Parses rarity data from `data/items.lua` and `data/weapons.lua` (both Weapons and Ammo tables).
    - Builds lookup maps and applies `rarity-*` classes to tiles in inventory and hotbar.
    - Watches the DOM (MutationObserver) to keep classes up-to-date as UI updates.
  - How it matches a tile to a rarity, in order:
    1) Background image filename (basename without extension)
    2) Name/key (e.g., `itemName`, `WEAPON_X`, `weapon_x`, `x`)
    3) Visible label text (normalized; e.g., `VAGOS AR` → `vagosar`)

- `web/build/assets/settings.css` (new)
  - Defines CSS variables for base theming:
    - `--oxinv-inv-bg` (tile background when no rarity is set)
    - `--oxinv-inv-border` (tile border color when no rarity is set)
    - `--oxinv-label-bg` (label bar background)
  - Ensures variables are only applied when a `rarity-*` class is NOT present, so rarity colors win.

- `web/build/assets/settings.js` (new)
  - Injects a `SETTINGS` button under the `CLOSE` button (same style as other control buttons).
  - Opens a modal with color pickers + opacity sliders.
  - Saves selection to `localStorage` key `oxinv_theme_v1` and reapplies on load.
  - Fallback shortcut: `F7` toggles the modal.

---

## Rarity values and style mapping

Supported rarity strings are currently:

- `common` → white-tinted background
- `legendary` → purple-tinted background
- `epic` → gold-tinted background

You can tweak the exact colors/alpha/glow in the rarity rules inside `index-9aba2ab3.css`.

---

## How to set rarity in data files

Add a `rarity = '...'` field to your item/weapon/ammo definition.

Examples:

```lua
-- data/items.lua
['burger'] = {
  label = 'Burger',
  weight = 220,
  rarity = 'epic',
}

-- data/weapons.lua (Weapons table)
['WEAPON_YELLOWFLAGAR'] = {
  label = 'VAGOS AR',
  weight = 23400,
  rarity = 'legendary',
  ammoname = 'ammo-rifle',
}

-- data/weapons.lua (Ammo table)
['ammo-9'] = {
  label = '9mm',
  weight = 7,
  rarity = 'common',
}
```

Notes on matching:
- Weapons are matched by `WEAPON_*`, `weapon_*`, the suffix (e.g., `yellowflagar`), the image filename, or the label (`VAGOS AR`).
- Items are matched by item name, image filename, or label.
- Ammo is matched by ammo name (e.g., `ammo-9`) or its label (`9mm`).

Restart the `ox_inventory` resource after editing these files.

---

## Using the Settings panel

Open inventory → click `SETTINGS` under `CLOSE` (or press `F7`).

You can change:
- Tile color + opacity (base background when no rarity is set)
- Tile border color + opacity
- Label bar color

Settings are saved per-player (on their PC) via localStorage and reload automatically next time.

Implementation details:
- CSS variables applied:
  - `--oxinv-inv-bg`, `--oxinv-inv-border`, `--oxinv-label-bg`
- Settings are in `settings.js` and styles in `settings.css`.

---

## Troubleshooting

- “Weapons don’t color”: ensure `rarity` is present on the weapon in `Weapons = { ... }`; the helper normalizes names and labels.
- “Ammo doesn’t color”: ensure `rarity` is present on the ammo entry in `Ammo = { ... }` and restart `ox_inventory`.
- “SETTINGS button missing”: press `F7`. If it shows, the button injection might be running before the controls mount—reopen inventory; the script uses a MutationObserver to insert the button once the controls exist.
- “Theme overrides my rarity colors”: by design, theme variables are only applied when a slot does NOT have a `rarity-*` class; verify the slot actually received the class.

---

## Customization and maintenance

- Change rarity colors: edit the `.rarity-*` rules in `index-9aba2ab3.css`.
- Change default theme values: update the defaults in `settings.js` (`loadTheme`) or override variables in `settings.css`.
- Disable the feature temporarily: remove the three includes from `index.html` (`rarity-hotbar.js`, `settings.css`, `settings.js`). The rarity CSS can stay—it’s inert without classes.

---

## Design notes

- We avoid patching the minified app bundle. Instead, we load small, robust helpers after the bundle. This keeps updates safer and easier to maintain.
- Parsing of Lua data is tolerant: it doesn’t require strict field order and supports comments. It reads items, weapons, and ammo.
- DOM updates are debounced via `requestAnimationFrame` and watched with a `MutationObserver` to handle inventory/hotbar changes.

---

## Next steps (optional)

- Server-side persistence: store theme per-character (metadata) via NUI callbacks instead of localStorage if you prefer central control.
- More rarity tiers: add new `.rarity-*` CSS rules and include them in your data.
- “Reset to defaults” button: small addition to `settings.js` if desired.
# Item Rarity System Implementation Guide

## Overview
This guide documents the rarity system implementation for ox_inventory with colored backgrounds: white (common), purple (legendary), and gold (epic).

## ✅ COMPLETED CHANGES

### 1. CSS Styling (✓ DONE)
**File:** `web\build\assets\index-9aba2ab3.css`

Added three rarity classes at the end of the file:
```css
.rarity-common{background-color:rgba(255,255,255,0.15);border-color:rgba(255,255,255,0.3)}
.rarity-legendary{background-color:rgba(138,43,226,0.25);border-color:rgba(138,43,226,0.5);box-shadow:0 0 10px rgba(138,43,226,0.3)}
.rarity-epic{background-color:rgba(255,215,0,0.2);border-color:rgba(255,215,0,0.5);box-shadow:0 0 10px rgba(255,215,0,0.3)}
```

**Visual Effects:**
- Common: White background with subtle transparency
- Legendary: Purple background with glow effect
- Epic: Gold background with glow effect

### 2. Lua Item Data (✓ DONE)
**File:** `data\items.lua`

Added example rarity properties to demonstrate usage:
```lua
['testburger'] = {
    label = 'Test Burger',
    weight = 220,
    degrade = 60,
    rarity = 'legendary',  -- ← ADDED
    client = { ... }
}

['bandage'] = {
    label = 'Bandage',
    weight = 115,
    rarity = 'common',  -- ← ADDED
}

['burger'] = {
    label = 'Burger',
    weight = 220,
    rarity = 'epic',  -- ← ADDED
    client = { ... }
}
```

```

#### What Changed:
- **Before:** `className:"inventory-slot"`
- **After:** ```className:`inventory-slot${gn(e)&&dt[e.name]?.rarity?` rarity-${dt[e.name].rarity}`:""}````

#### How It Works:
- Checks if item exists with `gn(e)`
- Looks up rarity property in item data: `dt[e.name]?.rarity`
- If rarity exists, appends the CSS class: `rarity-common`, `rarity-legendary`, or `rarity-epic`
- If no rarity, renders as normal: just `inventory-slot`

## 🎮 USAGE INSTRUCTIONS

### Adding Rarity to Items

In `data\items.lua` or `data\weapons.lua`, simply add the `rarity` property:

```lua
['item_name'] = {
    label = 'Item Label',
    weight = 100,
    rarity = 'common',      -- Options: 'common', 'legendary', 'epic'
    -- other properties...
}
```

### Valid Rarity Values:
- `'common'` → White background
- `'legendary'` → Purple background with glow
- `'epic'` → Gold background with glow
- No rarity property → Normal appearance (no colored background)

### Example Weapons:
```lua
['WEAPON_PISTOL'] = {
    label = 'Pistol',
    weight = 970,
    rarity = 'epic',  -- Gold background
    -- weapon properties...
}
```

## 🧪 TESTING

1. **Restart Server** after making the JavaScript edit
2. **Open Inventory** in-game
3. **Check Items** with rarity properties:
   - `testburger` should have **purple** background (legendary)
   - `bandage` should have **white** background (common)
   - `burger` should have **gold** background (epic)

## 📋 IMPLEMENTATION STATUS

| Component | Status | Notes |
|-----------|--------|-------|
| CSS Rarity Styles | ✅ Complete | Purple, white, and gold backgrounds with glow effects |
| Lua Item Examples | ✅ Complete | testburger (legendary), bandage (common), burger (epic) |

## 🔧 TROUBLESHOOTING

### Rarity Colors Not Showing
1. Verify JavaScript edit was applied correctly
2. Restart FiveM server completely
3. Clear browser cache (F5 won't work, need full cache clear)
4. Check browser console for JavaScript errors

### Items Have Wrong Colors
1. Verify rarity value is exactly `'common'`, `'legendary'`, or `'epic'`
2. Check for typos in item name or rarity property
3. Ensure Lua syntax is valid (commas, quotes)

### CSS Not Loading
1. Verify CSS file path: `web\build\assets\index-9aba2ab3.css`
2. Check that rarity classes were added at the END of the file
3. Ensure no syntax errors in CSS (missing braces, semicolons)

## 📝 NOTES

- The CSS and Lua changes are **COMPLETE** and working
- The shared module (`modules\items\shared.lua`) will automatically pass the rarity property from items to the frontend
- Items without a rarity property will display normally with no colored background
- The system is fully backward compatible

## 🎨 COLOR CUSTOMIZATION

To change colors, edit the CSS classes in `web\build\assets\index-9aba2ab3.css`:

```css
/* Common - White */
.rarity-common{
    background-color:rgba(255,255,255,0.15);  /* Adjust transparency here */
    border-color:rgba(255,255,255,0.3)
}

/* Legendary - Purple */
.rarity-legendary{
    background-color:rgba(138,43,226,0.25);  /* Adjust color/transparency */
    border-color:rgba(138,43,226,0.5);
    box-shadow:0 0 10px rgba(138,43,226,0.3)  /* Adjust glow intensity */
}

/* Epic - Gold */
.rarity-epic{
    background-color:rgba(255,215,0,0.2);  /* Adjust color/transparency */
    border-color:rgba(255,215,0,0.5);
    box-shadow:0 0 10px rgba(255,215,0,0.3)  /* Adjust glow intensity */
}
```
