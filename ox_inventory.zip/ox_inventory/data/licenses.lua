return {
	{ name = 'weapon', coords = vec3(12.42198, -1105.82, 29.7854), price = 5000 }
}